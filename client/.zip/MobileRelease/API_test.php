<script src="http://code.jquery.com/jquery-1.11.0.min.js"></script>
<script src="http://code.jquery.com/jquery-migrate-1.2.1.min.js"></script>

<html>
<body>
<div id="ModeSelect">
Select mode: <br><br>
<select id="ModeChoices">
	<option>
	
	<option value="Score">
	Score
	<option value="Module">
	Module	
	<option value="Question">
	Question
	<option value="Review">
	Review	
	<option value="Submit">
	Submit	
	<option value="Skip">
	Skip	
</select>
</div>
<br>
Data:<br><br>
<div id="DataEntry"></div><br>
<button id="sub">Submit</button><br><br>
<div id="Query"></div>
<div id="Result"></div>
</body>
</html>

<script type="text/javascript">
//	console.log('hi');
		function sqt_change(){
		console.log($('#sqt').val());
		switch($('#sqt').val()){
			case 'c':
			var data_string = "<input type='text' id='uanswer'></input>";
			break;
			case 'm':
			var data_string = "<input type='text' id='uanswer'><br>Note: Please enter comma separated uppercase letters in order with respect to the left hand side.";
			break;
			case 'mc':
			var data_string = "<select id='uanswer'><option><option value='A'>A<option value='B'>B<option value='C'>C<option value='D'>D<option value='E'>E<option value='F'>F</select>";
			break;
		};
		$('#user_answer').html(data_string);
		};
	$(function() {
		$.get('ajax/ITS_ajax_mobile.php', {id: 1}, function(data){console.log(data);});
	$('#ModeChoices').change(function(){
		switch($(this).val()){
			case 'Score':
			var data_string = "N/A";
			break;
			case 'Module':
			var data_string = "N/A";
			break;
			case 'Question':
			var data_string = "(Optional) Set current chapter number: <input type='number' id='set_q_num'>";
			break;
			case 'Review':
			var data_string = "(Optional) Change review index: <select id='rdx_choices'><option value='undefined'><option value='1'>Increment<option value='-1'>Decrement<option value='0'>Reset</select>";
			break;
			case 'Submit':
			var data_string = "Question id: <input type='number' id='su_q_num'><br>Question type:<select id='sqt' onchange='sqt_change()'><option><option value='c'>c<option value='m'>m<option value='mc'>mc</select><br>User answer: <span id='user_answer'>Please select question type.</span>";
			
			$('#DataEntry').change();
			$('#DataEntry').change();
			break;
			case 'Skip':
			var data_string = "Question id: <input type='number' id='sk_q_num'>";
			break;
		};
		$('#DataEntry').html(data_string);
	});
//	$('#DataEntry').change();
//Something is buggy with the following code, but it works for now...
//	$('#DataEntry').change(function(){
	//	console.log('hi');
	//});
	$('#sub').click(function(){
		//console.log('hi');
	//	var data_string = "Ajax call:<br><br>mode: " + $('#ModeChoices').val() + ", data: " + $('#set_q_num').val() + $('#rdx_choices').val() + $('#su_q_num').val() + $('#sk_q_num').val();
		
		var data_string = "$.get('ajax/ITS_ajax_mobile.php', {";
		switch($('#ModeChoices').val()){
			case 'Score':
			data_string += "action: 's'}";
			break;
			case 'Module':
			data_string += "action: 'm'}";
			break;
			case 'Question':
			//console.log($('#set_q_num').val().length);
			if (!$('#set_q_num').val()){
				data_string += "action: 'q'}";
			}
			else{
				data_string += "action: 'q', data: " + $('#set_q_num').val() + "}";
			}
			break;
			case 'Review':
			if ($('#rdx_choices').val() == "undefined"){
				data_string += "action: 'r'}";
			}
			else{
				data_string += "action: 'r', data: " + $('#rdx_choices').val() + "}";
			}
			break;
			case 'Submit':
			data_string += "action: 'submit', data: '" + $('#su_q_num').val() + "~" + $('#sqt').val() + "~" + $('#uanswer').val() + "'}";
			break;
			case 'Skip':
			data_string += "action: 'skip', data: " + $('#sk_q_num').val() + "}";
			break;
		};
		data_string += ", function(data){$('#Result').text(data);});";
		$('#Query').text(data_string);
		
		console.log(data_string);
		eval(data_string);
	})
});
</script>



<?php


?>
