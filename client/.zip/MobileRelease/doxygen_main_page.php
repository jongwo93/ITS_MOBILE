<?php
/*!
 * \mainpage Welcome to the ITS API documentation.
 * 
 * @section intro Getting Started
 * Go to ITS_ajax_mobile.php to get started.
 * 
 * */


?>
