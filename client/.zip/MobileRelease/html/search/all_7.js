var searchData=
[
  ['set_5fidr',['set_IDR',['../class_i_t_s__screen__mobile.html#a565dc817bdde24a96db50a1d272ce0c0',1,'ITS_screen_mobile']]]
];
