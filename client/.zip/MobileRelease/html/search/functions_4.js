var searchData=
[
  ['load_5fdata_5ffrom_5fdb',['load_DATA_from_DB',['../class_i_t_s__question__mobile.html#a8e32771769d553c4855751f254bf3941',1,'ITS_question_mobile']]]
];
