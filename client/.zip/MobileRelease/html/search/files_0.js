var searchData=
[
  ['config_5fmobile_2ephp',['config_mobile.php',['../config__mobile_8php.html',1,'']]]
];
