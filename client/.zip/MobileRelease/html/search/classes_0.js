var searchData=
[
  ['its_5fquestion_5fmobile',['ITS_question_mobile',['../class_i_t_s__question__mobile.html',1,'']]],
  ['its_5fscreen_5fmobile',['ITS_screen_mobile',['../class_i_t_s__screen__mobile.html',1,'']]]
];
