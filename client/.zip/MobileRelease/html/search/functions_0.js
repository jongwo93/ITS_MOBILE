var searchData=
[
  ['_5f_5fconstruct',['__construct',['../class_i_t_s__question__mobile.html#a4685b674563a0feb602f68fb615a5353',1,'ITS_question_mobile\__construct()'],['../class_i_t_s__screen__mobile.html#a29fbf41c0dea17bed2c0986bf8bf47c7',1,'ITS_screen_mobile\__construct()']]]
];
