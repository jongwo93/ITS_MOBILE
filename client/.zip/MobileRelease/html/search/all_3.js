var searchData=
[
  ['get_5fanswers_5fdata_5ffrom_5fdb',['get_ANSWERS_data_from_DB',['../class_i_t_s__question__mobile.html#aaec78378f229d88798582b1d96dfa5d8',1,'ITS_question_mobile']]],
  ['get_5fcategory',['get_CATEGORY',['../class_i_t_s__screen__mobile.html#aa1341a5b8e1fe6afc66d249a29b4a7ae',1,'ITS_screen_mobile']]],
  ['get_5fmc_5fstatistics',['get_MC_statistics',['../class_i_t_s__screen__mobile.html#ac021b78b1bfdc4dcf0752b67cfce67c2',1,'ITS_screen_mobile']]],
  ['get_5fquestion_5fscore',['get_QUESTION_score',['../class_i_t_s__screen__mobile.html#a431bbd9bc50b7628317238db3c2c6368',1,'ITS_screen_mobile']]],
  ['get_5fscreen',['get_SCREEN',['../class_i_t_s__screen__mobile.html#aa487a8e4aea532b8a5f3a9c07313a61f',1,'ITS_screen_mobile']]]
];
