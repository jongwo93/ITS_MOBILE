var searchData=
[
  ['its_5fajax_5fmobile_2ephp',['ITS_ajax_mobile.php',['../_i_t_s__ajax__mobile_8php.html',1,'']]],
  ['its_5fquestion_5fmobile_2ephp',['ITS_question_mobile.php',['../_i_t_s__question__mobile_8php.html',1,'']]],
  ['its_5fscreen_5fmobile_2ephp',['ITS_screen_mobile.php',['../_i_t_s__screen__mobile_8php.html',1,'']]]
];
