<!DOCTYPE html> 
<html> 
<head>
<title>ITS: Intelligent Tutoring System</title> 

<link rel="stylesheet" href="http://code.jquery.com/mobile/1.4.2/jquery.mobile-1.4.2.min.css" />
<script src="http://code.jquery.com/jquery-1.9.1.min.js"></script>
<script src="http://code.jquery.com/mobile/1.4.2/jquery.mobile-1.4.2.min.js"></script>
<script src="js/ITS_jquery_mobile.js"></script>

<div data-role="page">

<div data-role="header" data-position="fixed">
<a href="logout.php" data-icon="delete">Logout</a>
<h1> ITS Mobile </h1>
<a href="#" data-icon="search" data-iconpos="notext">Search</a>

<div data-role="navbar" data-theme="e" data-iconpos="top">
<ul>

<li><a id="s" onclick="updateScreen('s')" data-icon="home">Scores</a></li>
<li><a id="m" onclick="updateScreen('m')" data-icon="grid" class="ui-btn-active ui-state-persist">Modules</a></li>
<li><a id="q" onclick="updateScreen('q')" data-icon="star" >Questions</a></li>
<li><a id="r" onclick="updateScreen('r')" data-icon="back">Review</a></li>
			
</ul>
</div><!-- /navbar -->
</div><!-- /header -->
<div id="content" data-role="content"></div>

<script>
//Get user id somehow
$.get('ajax/ITS_ajax_mobile.php', {id: 1, action: 'm'}, function(data){$('#content').html(data).trigger("create")});

</script>
