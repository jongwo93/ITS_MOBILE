function updateScreen(mode)
{
	$(".ui-btn-active").removeClass("ui-btn-active");
	$("#" + mode).addClass("ui-btn-active ui-state-persist");
	//$.get('ajax/ITS_ajax_mobile.php', {mode: mode, format: 'HTML', module: module}, function(data){$('#content').html(data).trigger("create")});
	$.get('ajax/ITS_ajax_mobile.php', {action: mode}, function(data){$('#content').html(data).trigger("create")});

}

function submit(qNum, qType, chapter)
{
	var values = new Array();
	var c = [1,3,2,-4,-5];
	//var choice;
	switch (qType) {
		case 'm':
		$('.ui-block-a li input').each(function(index){
			values[index] = $(this).val();
		});
		//console.log(values);
		break;
		
		case 'mc':
		values[0] = $('.ui-radio-on').attr('for');
		//alert(choice);
		break;
		
		case 'c':
		values[0] = $('#ITS_TA').val();
		//console.log(choice);
		break;
	}
	//$.get('ajax/ITS_ajax_mobile.php', {mode: 'submit', format: 'HTML', module: qNum + '~' + qType + '~' + values + '~' + chapter + '~' + c}, function(data){$('#scoreContainer').html(data).trigger("create")});
}

$(document).ready(function(){
//$(".reviewPage").on("swiperight",function(){$.get('ajax/ITS_ajax_mobile.php', {mode: 'r', format: 'HTML', module: 1}, function(data){$('#content').html(data).trigger("create")});})
//$(".reviewPage").on("swipeleft",function(){$.get('ajax/ITS_ajax_mobile.php', {mode: 'r', format: 'HTML', module: -1}, function(data){$('#content').html(data).trigger("create")});})

});

